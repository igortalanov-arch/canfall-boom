import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { root, validAppId } from './setup.mjs';
export async function checkApp({ requireId = false } = {}) {
  const config = JSON.parse(await fs.readFile(path.join(root, 'vk-hosting-config.json'), 'utf8'));
  if (requireId && !validAppId(process.env.MINI_APPS_APP_ID || config.app_id)) throw new Error('ID приложения не настроен. Выполните npm run setup');
  const manifest = JSON.parse(await fs.readFile(path.join(root, 'public/manifest.json'), 'utf8'));
  if (manifest.version !== (await fs.readFile(path.join(root, 'VERSION'), 'utf8')).trim()) throw new Error('Stale public build; run npm run build');
  for (const [file, expected] of Object.entries(manifest.files)) {
    const data = await fs.readFile(path.join(root, 'public', file));
    if (createHash('sha256').update(data).digest('hex') !== expected) throw new Error('Checksum mismatch: ' + file);
  }
  const html = await fs.readFile(path.join(root, 'public/index.html'), 'utf8');
  const game = await fs.readFile(path.join(root, 'public/assets/game.js'), 'utf8');
  for (const id of ['language-select', 'theme-select', 'restore3d23', 'export23', 'import23', 'import-file23']) {
    if (html.includes(`id="${id}"`) || game.includes(id)) throw new Error('Removed setting remains: ' + id);
  }
  for (const platform of ['mobile', 'mvk', 'web']) if (config.endpoints?.[platform] !== 'index.html') throw new Error('Invalid endpoint: ' + platform);
  console.log('Build verified: assets, version, endpoints and removed settings.');
  if (!validAppId(config.app_id)) console.log('ID пока не задан; перед выкладкой он будет запрошен.');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  checkApp({ requireId: process.argv.includes('--require-id') }).catch(e => { console.error(e.message); process.exitCode = 1; });
}
