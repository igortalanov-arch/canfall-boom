import bridge from '@vkontakte/vk-bridge';

// Runs in <head>, before the game bundle; no CDN and no login/profile requests.
const params = new URLSearchParams(location.search);
const native = bridge.isWebView();
const inVK = native || params.has('vk_app_id') || /^https:\/\/(?:[\w-]+\.)?vk\.(?:com|ru)(?:\/|$)/i.test(document.referrer);
const state = window.canfallPlatform = { kind: inVK ? 'vk' : 'browser', hidden: false, init: 'pending' };
if (inVK) document.documentElement.dataset.vk = 'true';

function insets(data) {
  if (!inVK || !data?.insets) return;
  for (const side of ['top', 'right', 'bottom', 'left']) {
    const n = Number(data.insets[side]);
    document.documentElement.style.setProperty('--vk-' + side, (Number.isFinite(n) ? Math.max(0, Math.min(200, n)) : 0) + 'px');
  }
}
bridge.subscribe(event => {
  const { type, data } = event.detail || {};
  if (type === 'VKWebAppUpdateConfig' || type === 'VKWebAppUpdateInsets') insets(data);
  if (type === 'VKWebAppViewHide') {
    state.hidden = true;
    window.dispatchEvent(new Event('canfall:platform-hide'));
  } else if (type === 'VKWebAppViewRestore') {
    state.hidden = false;
    window.dispatchEvent(new Event('canfall:platform-restore'));
  }
});

// Failure outside VK must never prevent local preview or gameplay.
const timeout = setTimeout(() => { if (state.init === 'pending') state.init = 'unavailable'; }, 5000);
bridge.send('VKWebAppInit', {}).then(() => {
  clearTimeout(timeout); state.init = 'ready';
}).catch(() => {
  clearTimeout(timeout); state.init = 'unavailable';
});

// Rewarded ads only after explicit consent. Never grant a reward on failure or outside the platform.
let rewardReady33=false,rewardBusy33=false,preloadPromise33=null;
const limit33=(promise,ms)=>new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('Ad request timed out')),ms);promise.then(v=>{clearTimeout(t);resolve(v)},e=>{clearTimeout(t);reject(e)});});
window.canfallAds33=Object.freeze({
 kind:'platform',
 async preload(){
  if(!inVK||state.init!=='ready'||rewardBusy33)return false;
  if(rewardReady33)return true;
  if(preloadPromise33)return preloadPromise33;
  preloadPromise33=limit33(bridge.send('VKWebAppCheckNativeAds',{ad_format:'reward'}),10000).then(r=>{rewardReady33=r?.result===true;return rewardReady33},()=>false).finally(()=>{preloadPromise33=null});
  return preloadPromise33;
 },
 async show(){
  if(!inVK||state.init!=='ready'||!rewardReady33||rewardBusy33)return false;
  rewardBusy33=true;rewardReady33=false;
  try{const r=await limit33(bridge.send('VKWebAppShowNativeAds',{ad_format:'reward'}),180000);return r?.result===true;}
  catch{return false;}finally{rewardBusy33=false;}
 }
});
