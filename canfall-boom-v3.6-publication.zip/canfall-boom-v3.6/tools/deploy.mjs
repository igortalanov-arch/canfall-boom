import fs from 'node:fs/promises';
import path from 'node:path';
import { createRequire } from 'node:module';
import { createInterface } from 'node:readline/promises';
import { root, configure, deploymentConfig, validAppId } from './setup.mjs';
import { buildApp } from './build.mjs';
import { checkApp } from './check.mjs';

async function main() {
  process.chdir(root);
  const environment = process.argv[2] || 'dev';
  if (!['dev', 'production'].includes(environment)) throw new Error('Use dev or production');
  let config = JSON.parse(await fs.readFile(path.join(root, 'vk-hosting-config.json'), 'utf8'));
  const envId = process.env.MINI_APPS_APP_ID;
  if (envId && !validAppId(envId)) throw new Error('MINI_APPS_APP_ID is invalid');
  if (!envId && !validAppId(config.app_id)) {
    if (process.argv.includes('--dry-run')) throw new Error('Выкладка не настроена: сначала npm run setup. Ничего не отправлено.');
    config = await configure();
  }
  const target = deploymentConfig(envId || config.app_id, environment);
  await buildApp(); await checkApp({ requireId: true });
  console.log(`\nПриложение: https://vk.ru/app${target.app_id}`);
  console.log(`Окружение: ${environment}. Обновление production URL: ${target.update_prod ? 'ДА' : 'НЕТ'}.`);
  if (process.argv.includes('--dry-run')) { console.log('Проверка завершена. Ничего не отправлено в VK.'); return; }
  if (!process.stdin.isTTY) throw new Error('Для публикации нужен интерактивный терминал. Используйте DEPLOY.bat / DEPLOY-DEV.bat или npm run deploy.');
  const input = createInterface({ input: process.stdin, output: process.stdout });
  let answer;
  try { answer = (await input.question('Выложить именно в это приложение? Введите YES для продолжения: ')).trim(); } finally { input.close(); }
  if (answer.toUpperCase() !== 'YES') { console.log('Отменено. Ничего не отправлено.'); return; }
  process.env.MINI_APPS_ENVIRONMENT = environment;
  const require = createRequire(import.meta.url);
  // The official SDK reads this same cached object for auth and API calls.
  const liveConfig = require(path.join(root, 'vk-hosting-config.json'));
  for (const key of Object.keys(liveConfig)) delete liveConfig[key];
  Object.assign(liveConfig, target);
  const sdk = require('@vkontakte/vk-miniapps-deploy');
  const log = console.log;
  console.log = (...args) => log(...args.map(value => typeof value === 'string' ? value.replace(/(MINI_APPS_ACCESS_TOKEN=)\S+/g, '$1[hidden]') : value));
  try {
    const ok = await sdk.run(liveConfig);
    if (!ok) throw new Error('VK did not confirm deployment');
    log('Готово. Проверьте выданные SDK адреса и размещение в управлении приложением VK.');
  } finally { console.log = log; }
}
main().catch(e => { console.error(e.message); process.exitCode = 1; });
