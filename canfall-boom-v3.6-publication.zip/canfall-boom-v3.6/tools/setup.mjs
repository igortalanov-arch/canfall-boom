import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';
export const root = fileURLToPath(new URL('../', import.meta.url));
export function validAppId(value) {
  return /^\d+$/.test(String(value)) && Number.isSafeInteger(Number(value)) && Number(value) > 0;
}
export function deploymentConfig(id, environment) {
  if (!validAppId(id)) throw new Error('Нужен числовой ID вашего приложения VK, больше нуля.');
  if (!['production', 'dev'].includes(environment)) throw new Error('Unknown environment');
  return { app_id: Number(id), static_path: 'public', endpoints: { mobile: 'index.html', mvk: 'index.html', web: 'index.html' }, debug: false, update_prod: environment === 'production', update_dev: true };
}
export async function configure(explicitId) {
  let value = explicitId;
  if (!value) {
    if (!process.stdin.isTTY) throw new Error('Не задан ID приложения. Запустите npm run setup -- --app-id ВАШ_ID');
    const input = createInterface({ input: process.stdin, output: process.stdout });
    try { value = (await input.question('ID приложения «Банкопад» (число из vk.ru/app…): ')).trim(); } finally { input.close(); }
  }
  const config = deploymentConfig(value, 'dev');
  delete config.update_prod; delete config.update_dev;
  await fs.writeFile(path.join(root, 'vk-hosting-config.json'), JSON.stringify(config, null, 2) + '\n');
  console.log('Сохранено приложение: https://vk.ru/app' + config.app_id);
  return config;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const i = process.argv.indexOf('--app-id');
  configure(i >= 0 ? process.argv[i + 1] : undefined).catch(e => { console.error(e.message); process.exitCode = 1; });
}
