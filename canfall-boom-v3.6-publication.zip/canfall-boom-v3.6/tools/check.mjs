import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { root, validAppId } from './setup.mjs';
export async function checkApp({ requireId = false } = {}) {
  const config = JSON.parse(await fs.readFile(path.join(root, 'vk-hosting-config.json'), 'utf8'));
  if (requireId && !validAppId(process.env.MINI_APPS_APP_ID || config.app_id)) throw new Error('ID приложения не настроен. Выполните npm run setup');
  const manifest = JSON.parse(await fs.readFile(path.join(root, 'public/manifest.json'), 'utf8'));
  if (manifest.version !== (await fs.readFile(path.join(root, 'VERSION'), 'utf8')).trim()) throw new Error('Stale public build; run npm run build');
  for (const [file, expected] of Object.entries(manifest.files)) {
    const data = await fs.readFile(path.join(root, 'public', file));
    if (createHash('sha256').update(data).digest('hex') !== expected) throw new Error('Checksum mismatch: ' + file);
  }
  const html = await fs.readFile(path.join(root, 'public/index.html'), 'utf8');
  const game = await fs.readFile(path.join(root, 'public/assets/game.js'), 'utf8');
  for (const id of ['language-select', 'theme-select', 'restore3d23', 'export23', 'import23', 'import-file23', 'help-prev', 'help-counter', 'help-dots']) {
    if (html.includes(`id="${id}"`) || game.includes(id)) throw new Error('Removed setting remains: ' + id);
  }
  for (const marker of ["01 / 02", "importProgress23", "exportProgress:", "__CFcvparams", "challenge-platform", "cdn-cgi", "offline-button", "offline-dialog", "sound-toggle", "auto-search34", "auto-fail33", "__test33", "__ui33", "__auto33", "__audit33", "__live33", "__test34", "__ui34", "__auto34", "__audit34", "__live34", "__test36", "__ui36", "__auto36", "__audit36", "__live36", "__test35", "__ui35", "__auto35", "__audit35", "__live35"]) {
    if (game.includes(marker)) throw new Error('Obsolete or debug code remains: ' + marker);
  }
  if (!html.includes('data-ad-required33="true"')) throw new Error('Missing rewarded-ad edition guard');
  for (const platform of ['mobile', 'mvk', 'web']) if (config.endpoints?.[platform] !== 'index.html') throw new Error('Invalid endpoint: ' + platform);
  console.log('Build verified: assets, version, endpoints and removed settings.');
  if (!validAppId(config.app_id)) console.log('ID пока не задан; перед выкладкой он будет запрошен.');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  checkApp({ requireId: process.argv.includes('--require-id') }).catch(e => { console.error(e.message); process.exitCode = 1; });
}
