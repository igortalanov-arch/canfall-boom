@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 goto no_node
node -e "if(Number(process.versions.node.split('.')[0])<20)process.exit(1)"
if errorlevel 1 goto no_node
call npm ci --no-fund
if errorlevel 1 goto failed
call npm run deploy:dev
if errorlevel 1 goto failed
goto end
:no_node
echo Установите Node.js 22 или 24 LTS и повторите запуск.
goto end
:failed
echo Команда завершилась с ошибкой. Проверьте сообщение выше.
:end
pause
