import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { build } from 'esbuild';
export const root = fileURLToPath(new URL('../', import.meta.url));

export async function buildApp() {
  const htmlPath = path.join(root, 'src/game.html');
  let html = await fs.readFile(htmlPath, 'utf8');
  const version = (await fs.readFile(path.join(root, 'VERSION'), 'utf8')).trim();
  if (!html.includes(`version:"${version}"`)) throw new Error('VERSION does not match src/game.html');
  const css = html.match(/<style[^>]*>([\s\S]*?)<\/style>/i);
  const game = html.match(/<script\b[^>]*type="module"[^>]*>([\s\S]*?)<\/script>/i);
  if (!css || !game) throw new Error('Source HTML must contain the game module and embedded stylesheet');
  await fs.mkdir(path.join(root, 'public/assets'), { recursive: true });
  await fs.writeFile(path.join(root, 'public/assets/game.js'), game[1]);
  const safeArea = `
:root[data-vk=true]{--vk-safe-top:max(env(safe-area-inset-top,0px),var(--vk-top,0px));--vk-safe-right:max(env(safe-area-inset-right,0px),var(--vk-right,0px));--vk-safe-bottom:max(env(safe-area-inset-bottom,0px),var(--vk-bottom,0px));--vk-safe-left:max(env(safe-area-inset-left,0px),var(--vk-left,0px))}
:root[data-vk=true] body{padding:var(--vk-safe-top) var(--vk-safe-right) var(--vk-safe-bottom) var(--vk-safe-left)}
:root[data-vk=true] .game-screen{inset:var(--vk-safe-top) var(--vk-safe-right) var(--vk-safe-bottom) var(--vk-safe-left)!important;width:auto!important;height:calc(100dvh - var(--vk-safe-top) - var(--vk-safe-bottom))!important}
`;
  await fs.writeFile(path.join(root, 'public/assets/game.css'), css[1] + safeArea);
  await build({ entryPoints: [path.join(root, 'src/vk-adapter.js')], outfile: path.join(root, 'public/assets/vk-adapter.js'), bundle: true, minify: true, format: 'iife', platform: 'browser', target: 'es2022', legalComments: 'inline' });
  html = html.replace(css[0], '<link rel="stylesheet" href="./assets/game.css">');
  html = html.replace(game[0], '<script type="module" src="./assets/game.js"></script>');
  // A synchronous small local Bridge bundle initializes VK before main resources.
  html = html.replace('<head>', '<head><script src="./assets/vk-adapter.js"></script>');
  await fs.writeFile(path.join(root, 'public/index.html'), html);
  const license = await fs.readFile(path.join(root, 'node_modules/@vkontakte/vk-bridge/LICENSE'), 'utf8');
  await fs.writeFile(path.join(root, 'public/VK-BRIDGE-LICENSE.txt'), license);
  const files = ['index.html', 'assets/game.js', 'assets/game.css', 'assets/vk-adapter.js', 'VK-BRIDGE-LICENSE.txt'];
  const hashes = {};
  for (const file of files) hashes[file] = createHash('sha256').update(await fs.readFile(path.join(root, 'public', file))).digest('hex');
  await fs.writeFile(path.join(root, 'public/manifest.json'), JSON.stringify({ version, files: hashes }, null, 2) + '\n');
  console.log(`Built Canfall: Boom! ${version} -> public/`);
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  buildApp().catch(e => { console.error(e.message); process.exitCode = 1; });
}
